package com.restapitest.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.Test;

import com.restapitest.base.TestBase;
import com.restapitest.client.RestClient;

public class GetAPITest extends TestBase{
	
	@Test
	
	public void setUp() throws ClientProtocolException, IOException {
		//TestBase testBase = new TestBase();
		String url = prop.getProperty("URL")+prop.getProperty("ServiceURL");
		RestClient restClient = new RestClient();
		restClient.get(url);
		
	}

}
